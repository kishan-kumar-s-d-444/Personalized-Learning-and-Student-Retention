const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const mysql = require('mysql2/promise');
const dotenv = require("dotenv");
const app = express();
const Routes = require("./routes/route.js");
const PORT = process.env.PORT || 5000;
dotenv.config();
const { initializeDBConnections, db } = require('./config/db');

app.use(express.json({ limit: '10mb' }));
app.use(cors());

// Initialize database connections before starting the server
const startServer = async () => {
    try {
        await initializeDBConnections();
        
        // ... your middleware setup ...

        app.listen(process.env.PORT, () => {
            console.log(`Server started at port no. ${process.env.PORT}`);
        });
    } catch (error) {
        console.error('Failed to start server:', error);
    }
};

startServer();

app.use("/", Routes);

// Export both database connections
module.exports = { db };
